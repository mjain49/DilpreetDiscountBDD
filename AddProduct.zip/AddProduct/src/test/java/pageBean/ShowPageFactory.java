package pageBean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ShowPageFactory {

	// Driver definition
	WebDriver driver;

	// Initiating the Driver
	public ShowPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	@FindBy(id="navigate")
	@CacheLookup
	WebElement nav;
	
	@FindBy(id="dbtn")
	@CacheLookup
	WebElement dbtn;
	
	@FindBy(id="mbtn")
	@CacheLookup
	WebElement mbtn;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public void setNav() {
		this.nav.click();
	}

	public void setDbtn() {
		this.dbtn.click();
	}

	public void setMbtn() {
		this.mbtn.click();
	}
	
	
}