package showStepDefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;
import pageBean.DiscountPageFactory;
import pageBean.ShowPageFactory;

public class ShowTestClass {

	private WebDriver driver;
	private ShowPageFactory spf;

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "D:\\softwares\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		// driver=new FirefoxDriver();
	}

	@Given("^Admin is on 'Show-Discount' page$")
	public void admin_is_on_Show_Discount_page() throws Throwable {
		driver.get("D:\\BDD Workspace\\AddProduct\\target\\showDiscount.html");
		spf = new ShowPageFactory(driver);
		//Thread.sleep(5000);
	  
	}

	@When("^Admin click on update Button$")
	public void admin_click_on_update_Button() throws Throwable {
		spf.setMbtn();
	}

	@Then("^navigate to update-discount page$")
	public void navigate_to_update_discount_page() throws Throwable {
	  driver.get("D:\\\\BDD Workspace\\\\AddProduct\\\\target\\\\updateDiscount.html");
	  driver.close();
	}

	@When("^Admin click on delete Button$")
	public void admin_click_on_delete_Button() throws Throwable {
		spf.setDbtn();
	}

	@Then("^displays message 'Row deleted Sucessfully'$")
	public void displays_message_Row_deleted_Sucessfully() throws Throwable {
		String expectedMessage="Row Deleted Successfully";
		String actualMessage=driver.switchTo().alert().getText();
		Assert.assertEquals(expectedMessage, actualMessage);
		driver.switchTo().alert().accept();
		driver.close();
	}

	@When("^Admin click on AddDiscount Button$")
	public void admin_click_on_AddDiscount_Button() throws Throwable {
	    spf.setNav();
	}

	@Then("^navigate to AddDiscount page$")
	public void navigate_to_AddDiscount_page() throws Throwable {
		driver.get("D:\\\\BDD Workspace\\\\AddProduct\\\\target\\\\addDiscount.html");
	}
	
}